"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

interface Profile {
  id: string
  display_name: string
  user_type: string
  bio?: string
  location?: string
}

interface Comment {
  id: string
  content: string
  is_anonymous: boolean
  created_at: string
  author_id: string
  profiles: Profile
}

interface Post {
  id: string
  title: string
  content: string
  post_type: string
  tags: string[]
  is_anonymous: boolean
  created_at: string
  author_id: string
  profiles: Profile
}

interface PostCardProps {
  post: Post
  userProfile: Profile
  onUpdate: () => void
}

const POST_TYPE_COLORS = {
  question: "bg-blue-100 text-blue-800",
  support: "bg-green-100 text-green-800",
  celebration: "bg-yellow-100 text-yellow-800",
  resource: "bg-purple-100 text-purple-800",
}

export function PostCard({ post, userProfile, onUpdate }: PostCardProps) {
  const [comments, setComments] = useState<Comment[]>([])
  const [showComments, setShowComments] = useState(false)
  const [newComment, setNewComment] = useState("")
  const [isAnonymousComment, setIsAnonymousComment] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  const fetchComments = async () => {
    try {
      const { data, error } = await supabase
        .from("comments")
        .select(`
          *,
          profiles:author_id (
            id,
            display_name,
            user_type,
            bio,
            location
          )
        `)
        .eq("post_id", post.id)
        .order("created_at", { ascending: true })

      if (error) throw error
      setComments(data || [])
    } catch (error) {
      console.error("Error fetching comments:", error)
    }
  }

  useEffect(() => {
    if (showComments) {
      fetchComments()
    }
  }, [showComments, post.id])

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    setIsLoading(true)
    try {
      const { error } = await supabase.from("comments").insert({
        post_id: post.id,
        content: newComment.trim(),
        is_anonymous: isAnonymousComment,
        author_id: userProfile.id,
      })

      if (error) throw error

      setNewComment("")
      setIsAnonymousComment(false)
      fetchComments()
    } catch (error) {
      console.error("Error adding comment:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getAuthorDisplay = (profile: Profile, isAnonymous: boolean) => {
    if (isAnonymous) {
      return "Anonymous"
    }
    return profile.display_name
  }

  const getUserTypeDisplay = (userType: string) => {
    return userType === "volunteer" ? "Volunteer" : "Parent"
  }

  return (
    <Card className="shadow-sm hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge className={POST_TYPE_COLORS[post.post_type as keyof typeof POST_TYPE_COLORS]}>
                {post.post_type.charAt(0).toUpperCase() + post.post_type.slice(1)}
              </Badge>
              {post.tags.map((tag) => (
                <Badge key={tag} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">{post.title}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-500">
              <span>{getAuthorDisplay(post.profiles, post.is_anonymous)}</span>
              {!post.is_anonymous && (
                <Badge variant="secondary" className="text-xs">
                  {getUserTypeDisplay(post.profiles.user_type)}
                </Badge>
              )}
              <span>•</span>
              <span>{formatDate(post.created_at)}</span>
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-gray-700 mb-4 whitespace-pre-wrap">{post.content}</p>

        <div className="flex items-center gap-4 pt-3 border-t">
          <Button variant="ghost" size="sm" onClick={() => setShowComments(!showComments)}>
            {showComments ? "Hide" : "Show"} Comments ({comments.length})
          </Button>
        </div>

        {showComments && (
          <div className="mt-4 space-y-4">
            {/* Comments list */}
            <div className="space-y-3">
              {comments.map((comment) => (
                <div key={comment.id} className="bg-gray-50 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium text-sm">
                      {getAuthorDisplay(comment.profiles, comment.is_anonymous)}
                    </span>
                    {!comment.is_anonymous && (
                      <Badge variant="secondary" className="text-xs">
                        {getUserTypeDisplay(comment.profiles.user_type)}
                      </Badge>
                    )}
                    <span className="text-xs text-gray-500">{formatDate(comment.created_at)}</span>
                  </div>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{comment.content}</p>
                </div>
              ))}
            </div>

            {/* Add comment form */}
            <form onSubmit={handleAddComment} className="space-y-3">
              <Textarea
                placeholder="Add a supportive comment..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                rows={3}
              />
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id={`anonymous-${post.id}`}
                    checked={isAnonymousComment}
                    onCheckedChange={(checked) => setIsAnonymousComment(checked as boolean)}
                  />
                  <Label htmlFor={`anonymous-${post.id}`} className="text-sm">
                    Comment anonymously
                  </Label>
                </div>
                <Button type="submit" size="sm" disabled={isLoading || !newComment.trim()}>
                  {isLoading ? "Adding..." : "Add Comment"}
                </Button>
              </div>
            </form>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
