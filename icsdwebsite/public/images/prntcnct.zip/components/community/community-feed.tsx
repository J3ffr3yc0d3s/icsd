"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { PostCard } from "./post-card"
import { Button } from "@/components/ui/button"

interface Profile {
  id: string
  display_name: string
  user_type: string
  bio?: string
  location?: string
}

interface Post {
  id: string
  title: string
  content: string
  post_type: string
  tags: string[]
  is_anonymous: boolean
  created_at: string
  author_id: string
  profiles: Profile
}

interface CommunityFeedProps {
  userProfile: Profile
}

const POST_TYPE_FILTERS = [
  { value: "all", label: "All Posts" },
  { value: "question", label: "Questions" },
  { value: "support", label: "Support" },
  { value: "celebration", label: "Celebrations" },
  { value: "resource", label: "Resources" },
]

export function CommunityFeed({ userProfile }: CommunityFeedProps) {
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("all")
  const supabase = createClient()

  const fetchPosts = async () => {
    setLoading(true)
    try {
      let query = supabase
        .from("posts")
        .select(`
          *,
          profiles:author_id (
            id,
            display_name,
            user_type,
            bio,
            location
          )
        `)
        .order("created_at", { ascending: false })

      if (filter !== "all") {
        query = query.eq("post_type", filter)
      }

      const { data, error } = await query
      if (error) throw error
      setPosts(data || [])
    } catch (error) {
      console.error("Error fetching posts:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchPosts()
  }, [filter])

  const handlePostCreated = () => {
    fetchPosts()
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="bg-white rounded-lg shadow p-6 animate-pulse">
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Filter buttons */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap gap-2">
          {POST_TYPE_FILTERS.map((filterOption) => (
            <Button
              key={filterOption.value}
              variant={filter === filterOption.value ? "default" : "outline"}
              size="sm"
              onClick={() => setFilter(filterOption.value)}
            >
              {filterOption.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Posts */}
      <div className="space-y-4">
        {posts.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            <p className="text-gray-500">No posts found. Be the first to share something!</p>
          </div>
        ) : (
          posts.map((post) => (
            <PostCard key={post.id} post={post} userProfile={userProfile} onUpdate={handlePostCreated} />
          ))
        )}
      </div>
    </div>
  )
}
