"use client"

interface Profile {
  id: string
  display_name: string
  user_type: string
  bio?: string
  location?: string
}

interface Conversation {
  id: string
  participant_1_id: string
  participant_2_id: string
  created_at: string
  updated_at: string
  participant_1: Profile
  participant_2: Profile
  latest_message?: {
    content: string
    created_at: string
    sender_id: string
  }
}

interface ConversationListProps {
  conversations: Conversation[]
  userProfile: Profile
  selectedConversation: Conversation | null
  onSelectConversation: (conversation: Conversation) => void
  loading: boolean
}

export function ConversationList({
  conversations,
  userProfile,
  selectedConversation,
  onSelectConversation,
  loading,
}: ConversationListProps) {
  const getOtherParticipant = (conversation: Conversation) => {
    return conversation.participant_1_id === userProfile.id ? conversation.participant_2 : conversation.participant_1
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
      })
    } else {
      return date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      })
    }
  }

  if (loading) {
    return (
      <div className="p-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="mb-4 animate-pulse">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (conversations.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        <p>No conversations yet.</p>
        <p className="text-sm mt-1">Start by finding a volunteer to chat with!</p>
      </div>
    )
  }

  return (
    <div>
      {conversations.map((conversation) => {
        const otherParticipant = getOtherParticipant(conversation)
        const isSelected = selectedConversation?.id === conversation.id

        return (
          <div
            key={conversation.id}
            onClick={() => onSelectConversation(conversation)}
            className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
              isSelected ? "bg-blue-50 border-blue-200" : ""
            }`}
          >
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-medium">
                {otherParticipant.display_name.charAt(0).toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 truncate">{otherParticipant.display_name}</p>
                  {conversation.latest_message && (
                    <p className="text-xs text-gray-500">{formatTime(conversation.latest_message.created_at)}</p>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-xs text-blue-600 font-medium">
                    {otherParticipant.user_type === "volunteer" ? "Volunteer" : "Parent"}
                  </p>
                </div>
                {conversation.latest_message && (
                  <p className="text-sm text-gray-500 truncate mt-1">
                    {conversation.latest_message.sender_id === userProfile.id ? "You: " : ""}
                    {conversation.latest_message.content}
                  </p>
                )}
              </div>
            </div>
          </div>
        )
      })}
    </div>
  )
}
