"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { ConversationList } from "./conversation-list"
import { ChatWindow } from "./chat-window"
import { VolunteerList } from "./volunteer-list"

interface Profile {
  id: string
  display_name: string
  user_type: string
  bio?: string
  location?: string
}

interface Conversation {
  id: string
  participant_1_id: string
  participant_2_id: string
  created_at: string
  updated_at: string
  participant_1: Profile
  participant_2: Profile
  latest_message?: {
    content: string
    created_at: string
    sender_id: string
  }
}

interface ChatInterfaceProps {
  userProfile: Profile
}

export function ChatInterface({ userProfile }: ChatInterfaceProps) {
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [loading, setLoading] = useState(true)
  const [showVolunteers, setShowVolunteers] = useState(false)
  const supabase = createClient()

  const fetchConversations = async () => {
    setLoading(true)
    try {
      const { data, error } = await supabase
        .from("conversations")
        .select(`
          *,
          participant_1:participant_1_id (
            id,
            display_name,
            user_type,
            bio,
            location
          ),
          participant_2:participant_2_id (
            id,
            display_name,
            user_type,
            bio,
            location
          )
        `)
        .or(`participant_1_id.eq.${userProfile.id},participant_2_id.eq.${userProfile.id}`)
        .order("updated_at", { ascending: false })

      if (error) throw error

      // Get latest message for each conversation
      const conversationsWithMessages = await Promise.all(
        (data || []).map(async (conversation) => {
          const { data: latestMessage } = await supabase
            .from("messages")
            .select("content, created_at, sender_id")
            .eq("conversation_id", conversation.id)
            .order("created_at", { ascending: false })
            .limit(1)
            .single()

          return {
            ...conversation,
            latest_message: latestMessage,
          }
        }),
      )

      setConversations(conversationsWithMessages)
    } catch (error) {
      console.error("Error fetching conversations:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchConversations()
  }, [userProfile.id])

  const handleConversationSelect = (conversation: Conversation) => {
    setSelectedConversation(conversation)
    setShowVolunteers(false)
  }

  const handleNewConversation = async (volunteerId: string) => {
    try {
      // Check if conversation already exists
      const { data: existingConversation } = await supabase
        .from("conversations")
        .select("*")
        .or(
          `and(participant_1_id.eq.${userProfile.id},participant_2_id.eq.${volunteerId}),and(participant_1_id.eq.${volunteerId},participant_2_id.eq.${userProfile.id})`,
        )
        .single()

      if (existingConversation) {
        // Conversation exists, select it
        const { data: fullConversation } = await supabase
          .from("conversations")
          .select(`
            *,
            participant_1:participant_1_id (
              id,
              display_name,
              user_type,
              bio,
              location
            ),
            participant_2:participant_2_id (
              id,
              display_name,
              user_type,
              bio,
              location
            )
          `)
          .eq("id", existingConversation.id)
          .single()

        if (fullConversation) {
          setSelectedConversation(fullConversation)
          setShowVolunteers(false)
        }
      } else {
        // Create new conversation
        const { data: newConversation, error } = await supabase
          .from("conversations")
          .insert({
            participant_1_id: userProfile.id,
            participant_2_id: volunteerId,
          })
          .select(`
            *,
            participant_1:participant_1_id (
              id,
              display_name,
              user_type,
              bio,
              location
            ),
            participant_2:participant_2_id (
              id,
              display_name,
              user_type,
              bio,
              location
            )
          `)
          .single()

        if (error) throw error

        setSelectedConversation(newConversation)
        setShowVolunteers(false)
        fetchConversations()
      }
    } catch (error) {
      console.error("Error creating conversation:", error)
    }
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden" style={{ height: "600px" }}>
      <div className="flex h-full">
        {/* Sidebar */}
        <div className="w-1/3 border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <div className="flex gap-2">
              <button
                onClick={() => setShowVolunteers(false)}
                className={`px-3 py-1 rounded text-sm font-medium ${
                  !showVolunteers ? "bg-blue-100 text-blue-700" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Conversations
              </button>
              <button
                onClick={() => setShowVolunteers(true)}
                className={`px-3 py-1 rounded text-sm font-medium ${
                  showVolunteers ? "bg-blue-100 text-blue-700" : "text-gray-600 hover:text-gray-900"
                }`}
              >
                Find Volunteers
              </button>
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {showVolunteers ? (
              <VolunteerList userProfile={userProfile} onSelectVolunteer={handleNewConversation} />
            ) : (
              <ConversationList
                conversations={conversations}
                userProfile={userProfile}
                selectedConversation={selectedConversation}
                onSelectConversation={handleConversationSelect}
                loading={loading}
              />
            )}
          </div>
        </div>

        {/* Chat Window */}
        <div className="flex-1">
          {selectedConversation ? (
            <ChatWindow
              conversation={selectedConversation}
              userProfile={userProfile}
              onMessageSent={fetchConversations}
            />
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">
              <div className="text-center">
                <svg
                  className="w-12 h-12 mx-auto mb-4 text-gray-300"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"
                  />
                </svg>
                <p>Select a conversation to start chatting</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
