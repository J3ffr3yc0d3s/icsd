"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"

interface Profile {
  id: string
  display_name: string
  user_type: string
  bio?: string
  location?: string
}

interface VolunteerListProps {
  userProfile: Profile
  onSelectVolunteer: (volunteerId: string) => void
}

export function VolunteerList({ userProfile, onSelectVolunteer }: VolunteerListProps) {
  const [volunteers, setVolunteers] = useState<Profile[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const fetchVolunteers = async () => {
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("*")
          .eq("user_type", "volunteer")
          .neq("id", userProfile.id)

        if (error) throw error
        setVolunteers(data || [])
      } catch (error) {
        console.error("Error fetching volunteers:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchVolunteers()
  }, [userProfile.id])

  if (loading) {
    return (
      <div className="p-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="mb-4 animate-pulse">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
              <div className="flex-1">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (volunteers.length === 0) {
    return (
      <div className="p-4 text-center text-gray-500">
        <p>No volunteers available at the moment.</p>
      </div>
    )
  }

  return (
    <div>
      {volunteers.map((volunteer) => (
        <div
          key={volunteer.id}
          onClick={() => onSelectVolunteer(volunteer.id)}
          className="p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center text-white font-medium">
              {volunteer.display_name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-gray-900 truncate">{volunteer.display_name}</p>
                <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                  Volunteer
                </span>
              </div>
              {volunteer.bio && <p className="text-sm text-gray-500 truncate mt-1">{volunteer.bio}</p>}
              {volunteer.location && <p className="text-xs text-gray-400 mt-1">{volunteer.location}</p>}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
