"use client"

import { useState } from "react"
import { PPDTestIntro } from "./ppd-test-intro"
import { PPDTestQuestions } from "./ppd-test-questions"
import { PPDTestResults } from "./ppd-test-results"

interface Profile {
  id: string
  display_name: string
  user_type: string
}

interface PPDTestInterfaceProps {
  userProfile: Profile
}

export type TestStep = "intro" | "questions" | "results"

export interface TestResult {
  answers: Record<string, number>
  totalScore: number
  riskLevel: "low" | "moderate" | "high"
  recommendations: string[]
}

export function PPDTestInterface({ userProfile }: PPDTestInterfaceProps) {
  const [currentStep, setCurrentStep] = useState<TestStep>("intro")
  const [testResult, setTestResult] = useState<TestResult | null>(null)

  const handleStartTest = () => {
    setCurrentStep("questions")
  }

  const handleTestComplete = (result: TestResult) => {
    setTestResult(result)
    setCurrentStep("results")
  }

  const handleRetakeTest = () => {
    setTestResult(null)
    setCurrentStep("intro")
  }

  return (
    <div>
      {currentStep === "intro" && <PPDTestIntro onStartTest={handleStartTest} />}
      {currentStep === "questions" && (
        <PPDTestQuestions userProfile={userProfile} onTestComplete={handleTestComplete} />
      )}
      {currentStep === "results" && testResult && (
        <PPDTestResults result={testResult} onRetakeTest={handleRetakeTest} />
      )}
    </div>
  )
}
