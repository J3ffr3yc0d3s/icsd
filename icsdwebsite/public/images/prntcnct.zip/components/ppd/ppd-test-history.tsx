"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"

interface Profile {
  id: string
  display_name: string
  user_type: string
}

interface PPDTest {
  id: string
  total_score: number
  risk_level: "low" | "moderate" | "high"
  taken_at: string
  recommendations: string[]
}

interface PPDTestHistoryProps {
  userProfile: Profile
}

const RISK_LEVEL_CONFIG = {
  low: {
    color: "bg-green-100 text-green-800",
    title: "Low Risk",
  },
  moderate: {
    color: "bg-yellow-100 text-yellow-800",
    title: "Moderate Risk",
  },
  high: {
    color: "bg-red-100 text-red-800",
    title: "High Risk",
  },
}

export function PPDTestHistory({ userProfile }: PPDTestHistoryProps) {
  const [tests, setTests] = useState<PPDTest[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = createClient()

  useEffect(() => {
    const fetchTestHistory = async () => {
      try {
        const { data, error } = await supabase
          .from("ppd_tests")
          .select("*")
          .eq("user_id", userProfile.id)
          .order("taken_at", { ascending: false })

        if (error) throw error
        setTests(data || [])
      } catch (error) {
        console.error("Error fetching test history:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchTestHistory()
  }, [userProfile.id])

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Test History</h1>
        </div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">PPD Test History</h1>
          <p className="text-gray-600">Track your mental health assessments over time</p>
        </div>
        <Link href="/ppd-test">
          <Button>Take New Assessment</Button>
        </Link>
      </div>

      {tests.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No assessments yet</h3>
            <p className="text-gray-600 mb-4">Take your first PPD assessment to start tracking your mental health.</p>
            <Link href="/ppd-test">
              <Button>Take Assessment</Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {tests.map((test) => {
            const config = RISK_LEVEL_CONFIG[test.risk_level]
            return (
              <Card key={test.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg">Assessment Results</CardTitle>
                      <p className="text-sm text-gray-600">{formatDate(test.taken_at)}</p>
                    </div>
                    <div className="text-right">
                      <Badge className={config.color}>{config.title}</Badge>
                      <p className="text-sm text-gray-600 mt-1">Score: {test.total_score}/30</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <h4 className="font-medium text-gray-900">Recommendations from this assessment:</h4>
                    <ul className="space-y-1">
                      {test.recommendations.slice(0, 2).map((recommendation, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{recommendation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      )}

      <Card className="bg-blue-50">
        <CardContent className="pt-6">
          <div className="text-center">
            <h3 className="font-semibold text-blue-900 mb-2">Need Support?</h3>
            <p className="text-blue-800 text-sm mb-4">
              Remember that seeking help is a sign of strength. Our community and volunteers are here to support you.
            </p>
            <div className="flex justify-center gap-4">
              <Link href="/community">
                <Button variant="outline" size="sm">
                  Join Community
                </Button>
              </Link>
              <Link href="/chat">
                <Button variant="outline" size="sm">
                  Chat with Volunteers
                </Button>
              </Link>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
