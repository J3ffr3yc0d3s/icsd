"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { TestResult } from "./ppd-test-interface"

interface Profile {
  id: string
  display_name: string
  user_type: string
}

interface PPDTestQuestionsProps {
  userProfile: Profile
  onTestComplete: (result: TestResult) => void
}

const PPD_QUESTIONS = [
  {
    id: "q1",
    text: "I have been able to laugh and see the funny side of things",
    options: [
      { value: 0, text: "As much as I always could" },
      { value: 1, text: "Not quite so much now" },
      { value: 2, text: "Definitely not so much now" },
      { value: 3, text: "Not at all" },
    ],
  },
  {
    id: "q2",
    text: "I have looked forward with enjoyment to things",
    options: [
      { value: 0, text: "As much as I ever did" },
      { value: 1, text: "Rather less than I used to" },
      { value: 2, text: "Definitely less than I used to" },
      { value: 3, text: "Hardly at all" },
    ],
  },
  {
    id: "q3",
    text: "I have blamed myself unnecessarily when things went wrong",
    options: [
      { value: 3, text: "Yes, most of the time" },
      { value: 2, text: "Yes, some of the time" },
      { value: 1, text: "Not very often" },
      { value: 0, text: "No, never" },
    ],
  },
  {
    id: "q4",
    text: "I have been anxious or worried for no good reason",
    options: [
      { value: 0, text: "No, not at all" },
      { value: 1, text: "Hardly ever" },
      { value: 2, text: "Yes, sometimes" },
      { value: 3, text: "Yes, very often" },
    ],
  },
  {
    id: "q5",
    text: "I have felt scared or panicky for no very good reason",
    options: [
      { value: 3, text: "Yes, quite a lot" },
      { value: 2, text: "Yes, sometimes" },
      { value: 1, text: "No, not much" },
      { value: 0, text: "No, not at all" },
    ],
  },
  {
    id: "q6",
    text: "Things have been getting on top of me",
    options: [
      { value: 3, text: "Yes, most of the time I haven't been able to cope at all" },
      { value: 2, text: "Yes, sometimes I haven't been coping as well as usual" },
      { value: 1, text: "No, most of the time I have coped quite well" },
      { value: 0, text: "No, I have been coping as well as ever" },
    ],
  },
  {
    id: "q7",
    text: "I have been so unhappy that I have had difficulty sleeping",
    options: [
      { value: 3, text: "Yes, most of the time" },
      { value: 2, text: "Yes, sometimes" },
      { value: 1, text: "Not very often" },
      { value: 0, text: "No, not at all" },
    ],
  },
  {
    id: "q8",
    text: "I have felt sad or miserable",
    options: [
      { value: 3, text: "Yes, most of the time" },
      { value: 2, text: "Yes, quite often" },
      { value: 1, text: "Not very often" },
      { value: 0, text: "No, not at all" },
    ],
  },
  {
    id: "q9",
    text: "I have been so unhappy that I have been crying",
    options: [
      { value: 3, text: "Yes, most of the time" },
      { value: 2, text: "Yes, quite often" },
      { value: 1, text: "Only occasionally" },
      { value: 0, text: "No, never" },
    ],
  },
  {
    id: "q10",
    text: "The thought of harming myself has occurred to me",
    options: [
      { value: 3, text: "Yes, quite often" },
      { value: 2, text: "Sometimes" },
      { value: 1, text: "Hardly ever" },
      { value: 0, text: "Never" },
    ],
  },
]

export function PPDTestQuestions({ userProfile, onTestComplete }: PPDTestQuestionsProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const supabase = createClient()

  const handleAnswerSelect = (questionId: string, value: number) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }))
  }

  const handleNext = () => {
    if (currentQuestion < PPD_QUESTIONS.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const calculateResults = (answers: Record<string, number>): TestResult => {
    const totalScore = Object.values(answers).reduce((sum, score) => sum + score, 0)

    let riskLevel: "low" | "moderate" | "high"
    let recommendations: string[]

    if (totalScore <= 9) {
      riskLevel = "low"
      recommendations = [
        "Your responses suggest a low likelihood of postpartum depression.",
        "Continue to monitor your mental health and practice self-care.",
        "Stay connected with supportive friends and family.",
        "Consider joining parent support groups in your community.",
      ]
    } else if (totalScore <= 12) {
      riskLevel = "moderate"
      recommendations = [
        "Your responses suggest you may be experiencing some symptoms of postpartum depression.",
        "Consider speaking with your healthcare provider about your feelings.",
        "Reach out to trusted friends, family, or support groups.",
        "Practice stress-reduction techniques like meditation or gentle exercise.",
        "Monitor your symptoms and seek help if they worsen.",
      ]
    } else {
      riskLevel = "high"
      recommendations = [
        "Your responses suggest you may be experiencing significant symptoms of postpartum depression.",
        "We strongly recommend speaking with a healthcare professional as soon as possible.",
        "Contact your doctor, a mental health professional, or a postpartum support hotline.",
        "Remember that postpartum depression is treatable and you're not alone.",
        "Consider reaching out to trusted friends or family for immediate support.",
      ]
    }

    return {
      answers,
      totalScore,
      riskLevel,
      recommendations,
    }
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      const result = calculateResults(answers)

      // Save to database
      const { error } = await supabase.from("ppd_tests").insert({
        user_id: userProfile.id,
        answers: result.answers,
        total_score: result.totalScore,
        risk_level: result.riskLevel,
        recommendations: result.recommendations,
      })

      if (error) throw error

      onTestComplete(result)
    } catch (error) {
      console.error("Error saving test results:", error)
      // Still show results even if save fails
      onTestComplete(calculateResults(answers))
    } finally {
      setIsSubmitting(false)
    }
  }

  const progress = ((currentQuestion + 1) / PPD_QUESTIONS.length) * 100
  const currentQ = PPD_QUESTIONS[currentQuestion]
  const currentAnswer = answers[currentQ.id]
  const isLastQuestion = currentQuestion === PPD_QUESTIONS.length - 1

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">PPD Assessment</h1>
        <p className="text-gray-600">
          Question {currentQuestion + 1} of {PPD_QUESTIONS.length}
        </p>
      </div>

      <div className="max-w-2xl mx-auto">
        <Progress value={progress} className="mb-6" />

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">In the past 7 days: {currentQ.text}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {currentQ.options.map((option) => (
              <label
                key={option.value}
                className={`flex items-center p-3 rounded-lg border cursor-pointer transition-colors ${
                  currentAnswer === option.value
                    ? "border-blue-500 bg-blue-50"
                    : "border-gray-200 hover:border-gray-300"
                }`}
              >
                <input
                  type="radio"
                  name={currentQ.id}
                  value={option.value}
                  checked={currentAnswer === option.value}
                  onChange={() => handleAnswerSelect(currentQ.id, option.value)}
                  className="sr-only"
                />
                <div
                  className={`w-4 h-4 rounded-full border-2 mr-3 ${
                    currentAnswer === option.value ? "border-blue-500 bg-blue-500" : "border-gray-300"
                  }`}
                >
                  {currentAnswer === option.value && <div className="w-2 h-2 bg-white rounded-full m-0.5" />}
                </div>
                <span className="text-gray-900">{option.text}</span>
              </label>
            ))}
          </CardContent>
        </Card>

        <div className="flex justify-between mt-6">
          <Button variant="outline" onClick={handlePrevious} disabled={currentQuestion === 0}>
            Previous
          </Button>
          {isLastQuestion ? (
            <Button onClick={handleSubmit} disabled={currentAnswer === undefined || isSubmitting}>
              {isSubmitting ? "Submitting..." : "Complete Assessment"}
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={currentAnswer === undefined}>
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
