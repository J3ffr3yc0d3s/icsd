"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface PPDTestIntroProps {
  onStartTest: () => void
}

export function PPDTestIntro({ onStartTest }: PPDTestIntroProps) {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Postpartum Depression Screening</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          This confidential assessment can help identify signs of postpartum depression and provide personalized
          resources for support.
        </p>
      </div>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="text-xl">About This Assessment</CardTitle>
          <CardDescription>
            This screening is based on the Edinburgh Postnatal Depression Scale (EPDS), a widely used tool for
            identifying postpartum depression.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">What to Expect:</h3>
            <ul className="text-blue-800 text-sm space-y-1">
              <li>• 10 questions about your feelings and experiences</li>
              <li>• Takes approximately 5 minutes to complete</li>
              <li>• Your responses are completely confidential</li>
              <li>• Receive personalized recommendations based on your results</li>
            </ul>
          </div>

          <div className="bg-amber-50 p-4 rounded-lg">
            <h3 className="font-semibold text-amber-900 mb-2">Important Note:</h3>
            <p className="text-amber-800 text-sm">
              This screening is not a diagnosis. If you're experiencing thoughts of self-harm or harming others, please
              seek immediate professional help or call a crisis hotline.
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <h3 className="font-semibold text-green-900 mb-2">Your Privacy:</h3>
            <p className="text-green-800 text-sm">
              Your responses are stored securely and only you can access your results. This information is never shared
              without your explicit consent.
            </p>
          </div>

          <div className="pt-4">
            <Button onClick={onStartTest} className="w-full" size="lg">
              Start Assessment
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
