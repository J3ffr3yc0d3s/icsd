"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import type { TestResult } from "./ppd-test-interface"

interface PPDTestResultsProps {
  result: TestResult
  onRetakeTest: () => void
}

const RISK_LEVEL_CONFIG = {
  low: {
    color: "bg-green-100 text-green-800",
    title: "Low Risk",
    description: "Your responses suggest a low likelihood of postpartum depression.",
  },
  moderate: {
    color: "bg-yellow-100 text-yellow-800",
    title: "Moderate Risk",
    description: "Your responses suggest you may be experiencing some symptoms of postpartum depression.",
  },
  high: {
    color: "bg-red-100 text-red-800",
    title: "High Risk",
    description: "Your responses suggest you may be experiencing significant symptoms of postpartum depression.",
  },
}

const CRISIS_RESOURCES = [
  {
    name: "National Suicide Prevention Lifeline",
    phone: "988",
    description: "24/7 crisis support",
  },
  {
    name: "Postpartum Support International Helpline",
    phone: "1-944-4773",
    description: "Specialized postpartum support",
  },
  {
    name: "Crisis Text Line",
    phone: "Text HOME to 741741",
    description: "24/7 text-based crisis support",
  },
]

export function PPDTestResults({ result, onRetakeTest }: PPDTestResultsProps) {
  const config = RISK_LEVEL_CONFIG[result.riskLevel]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Your Assessment Results</h1>
        <p className="text-gray-600">Based on your responses to the Edinburgh Postnatal Depression Scale</p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Score and Risk Level */}
        <Card>
          <CardHeader className="text-center">
            <div className="flex justify-center mb-2">
              <Badge className={config.color}>{config.title}</Badge>
            </div>
            <CardTitle className="text-2xl">Score: {result.totalScore}/30</CardTitle>
            <CardDescription>{config.description}</CardDescription>
          </CardHeader>
        </Card>

        {/* Recommendations */}
        <Card>
          <CardHeader>
            <CardTitle>Personalized Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {result.recommendations.map((recommendation, index) => (
                <li key={index} className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0" />
                  <span className="text-gray-700">{recommendation}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Crisis Resources (show for moderate/high risk) */}
        {(result.riskLevel === "moderate" || result.riskLevel === "high") && (
          <Card className="border-red-200 bg-red-50">
            <CardHeader>
              <CardTitle className="text-red-900">Immediate Support Resources</CardTitle>
              <CardDescription className="text-red-700">
                If you're in crisis or having thoughts of self-harm, please reach out immediately:
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {CRISIS_RESOURCES.map((resource, index) => (
                  <div key={index} className="bg-white p-3 rounded-lg border border-red-200">
                    <div className="font-semibold text-red-900">{resource.name}</div>
                    <div className="text-red-800 font-mono">{resource.phone}</div>
                    <div className="text-red-700 text-sm">{resource.description}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Next Steps */}
        <Card>
          <CardHeader>
            <CardTitle>What's Next?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Link href="/community">
                <div className="bg-blue-50 p-4 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer">
                  <h3 className="font-semibold text-blue-900 mb-2">Join Our Community</h3>
                  <p className="text-blue-700 text-sm">Connect with other parents who understand your journey</p>
                </div>
              </Link>
              <Link href="/chat">
                <div className="bg-green-50 p-4 rounded-lg hover:bg-green-100 transition-colors cursor-pointer">
                  <h3 className="font-semibold text-green-900 mb-2">Chat with Volunteers</h3>
                  <p className="text-green-700 text-sm">Get personalized support from trained volunteers</p>
                </div>
              </Link>
            </div>

            <div className="flex gap-4 pt-4">
              <Button onClick={onRetakeTest} variant="outline">
                Retake Assessment
              </Button>
              <Link href="/ppd-test/history">
                <Button variant="outline">View Test History</Button>
              </Link>
              <Link href="/dashboard">
                <Button>Return to Dashboard</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <Card className="bg-gray-50">
          <CardContent className="pt-6">
            <p className="text-sm text-gray-600 text-center">
              <strong>Important:</strong> This screening is not a medical diagnosis. Please consult with a healthcare
              professional for proper evaluation and treatment. If you're experiencing a mental health emergency, please
              call 911 or go to your nearest emergency room.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
