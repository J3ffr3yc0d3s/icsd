-- Create PPD test results table
CREATE TABLE IF NOT EXISTS public.ppd_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  answers JSONB NOT NULL, -- Store all answers as JSON
  total_score INTEGER NOT NULL,
  risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'moderate', 'high')),
  recommendations TEXT[],
  taken_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.ppd_tests ENABLE ROW LEVEL SECURITY;

-- RLS Policies for PPD tests - only user can see their own results
CREATE POLICY "ppd_tests_select_own" 
  ON public.ppd_tests FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "ppd_tests_insert_own" 
  ON public.ppd_tests FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "ppd_tests_update_own" 
  ON public.ppd_tests FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "ppd_tests_delete_own" 
  ON public.ppd_tests FOR DELETE 
  USING (auth.uid() = user_id);
