-- Create conversations table for chat
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  participant_1_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  participant_2_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(participant_1_id, participant_2_id)
);

-- Enable RLS
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for conversations
CREATE POLICY "conversations_select_participants" 
  ON public.conversations FOR SELECT 
  USING (auth.uid() = participant_1_id OR auth.uid() = participant_2_id);

CREATE POLICY "conversations_insert_participants" 
  ON public.conversations FOR INSERT 
  WITH CHECK (auth.uid() = participant_1_id OR auth.uid() = participant_2_id);

CREATE POLICY "conversations_update_participants" 
  ON public.conversations FOR UPDATE 
  USING (auth.uid() = participant_1_id OR auth.uid() = participant_2_id);

CREATE POLICY "conversations_delete_participants" 
  ON public.conversations FOR DELETE 
  USING (auth.uid() = participant_1_id OR auth.uid() = participant_2_id);

-- Create updated_at trigger for conversations
CREATE TRIGGER update_conversations_updated_at 
  BEFORE UPDATE ON public.conversations 
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
