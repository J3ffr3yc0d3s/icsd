import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { CommunityFeed } from "@/components/community/community-feed"
import { CreatePostForm } from "@/components/community/create-post-form"

export default async function CommunityPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

  if (!profile) {
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Community Feed</h1>
          <p className="text-gray-600">Connect with other parents and share your experiences</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <CommunityFeed userProfile={profile} />
          </div>
          <div className="lg:col-span-1">
            <CreatePostForm userProfile={profile} />
          </div>
        </div>
      </div>
    </div>
  )
}
