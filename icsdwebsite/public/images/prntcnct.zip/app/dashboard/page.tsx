import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function DashboardPage() {
  const supabase = await createClient()

  const { data, error } = await supabase.auth.getUser()
  if (error || !data?.user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).single()

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            Welcome to ParentConnect, {profile?.display_name || "Friend"}!
          </h1>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link href="/community">
              <div className="bg-blue-50 p-4 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer">
                <h2 className="font-semibold text-blue-900 mb-2">Community Feed</h2>
                <p className="text-blue-700 text-sm">Connect with other parents and share experiences</p>
              </div>
            </Link>
            <Link href="/chat">
              <div className="bg-green-50 p-4 rounded-lg hover:bg-green-100 transition-colors cursor-pointer">
                <h2 className="font-semibold text-green-900 mb-2">Chat with Volunteers</h2>
                <p className="text-green-700 text-sm">Get support from experienced parents</p>
              </div>
            </Link>
            <Link href="/ppd-test">
              <div className="bg-purple-50 p-4 rounded-lg hover:bg-purple-100 transition-colors cursor-pointer">
                <h2 className="font-semibold text-purple-900 mb-2">PPD Assessment</h2>
                <p className="text-purple-700 text-sm">Take a confidential mental health screening</p>
              </div>
            </Link>
          </div>

          <div className="mt-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Profile</h2>
            <div className="bg-gray-50 p-4 rounded-lg">
              <p>
                <strong>Email:</strong> {data.user.email}
              </p>
              <p>
                <strong>Display Name:</strong> {profile?.display_name}
              </p>
              <p>
                <strong>User Type:</strong> {profile?.user_type}
              </p>
              {profile?.bio && (
                <p>
                  <strong>Bio:</strong> {profile.bio}
                </p>
              )}
              {profile?.location && (
                <p>
                  <strong>Location:</strong> {profile.location}
                </p>
              )}
            </div>
          </div>

          <div className="mt-6 flex gap-4">
            <Link href="/community">
              <Button>Visit Community</Button>
            </Link>
            <Link href="/chat">
              <Button variant="outline">Start Chatting</Button>
            </Link>
            <Link href="/ppd-test">
              <Button variant="outline">Take PPD Assessment</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
