"use client"

import type React from "react"

import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useState } from "react"

type UserType = "user" | "volunteer"

interface SignupForm {
  email: string
  password: string
  confirmPassword: string
  displayName: string
  userType: UserType
  bio?: string
  location?: string
  childrenAges?: string[]
  interests?: string[]
  isVerified?: boolean
}

const CHILDREN_AGE_OPTIONS = ["0-1", "1-2", "2-3", "3-4", "4-5", "5+"]
const INTEREST_OPTIONS = [
  "Postpartum Support",
  "Sleep Training",
  "Feeding",
  "Development",
  "Mental Health",
  "Work-Life Balance",
]

export default function SignupPage() {
  const [step, setStep] = useState(1)
  const [form, setForm] = useState<SignupForm>({
    email: "",
    password: "",
    confirmPassword: "",
    displayName: "",
    userType: "user",
    bio: "",
    location: "",
    childrenAges: [],
    interests: [],
  })
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleInputChange = (field: keyof SignupForm, value: any) => {
    setForm((prev) => ({ ...prev, [field]: value }))
  }

  const handleArrayToggle = (field: "childrenAges" | "interests", value: string) => {
    setForm((prev) => ({
      ...prev,
      [field]: prev[field]?.includes(value)
        ? prev[field].filter((item) => item !== value)
        : [...(prev[field] || []), value],
    }))
  }

  const validateStep1 = () => {
    if (!form.email || !form.password || !form.confirmPassword || !form.displayName) {
      setError("Please fill in all required fields")
      return false
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match")
      return false
    }
    if (form.password.length < 6) {
      setError("Password must be at least 6 characters")
      return false
    }
    return true
  }

  const handleNext = () => {
    setError(null)
    if (step === 1 && validateStep1()) {
      setStep(2)
    }
  }

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    const supabase = createClient()
    setIsLoading(true)
    setError(null)

    try {
      const { error } = await supabase.auth.signUp({
        email: form.email,
        password: form.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
          data: {
            display_name: form.displayName,
            user_type: form.userType,
            bio: form.bio,
            location: form.location,
            children_ages: form.childrenAges,
            interests: form.interests,
          },
        },
      })
      if (error) throw error
      router.push("/auth/signup-success")
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-gray-900">Join ParentConnect</CardTitle>
            <CardDescription className="text-gray-600">
              Step {step} of 2: {step === 1 ? "Basic Information" : "Profile Details"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {step === 1 ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your@email.com"
                    required
                    value={form.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="displayName">Display Name *</Label>
                  <Input
                    id="displayName"
                    type="text"
                    placeholder="How others will see you"
                    required
                    value={form.displayName}
                    onChange={(e) => handleInputChange("displayName", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password *</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    value={form.password}
                    onChange={(e) => handleInputChange("password", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirm Password *</Label>
                  <Input
                    id="confirmPassword"
                    type="password"
                    required
                    value={form.confirmPassword}
                    onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                  />
                </div>
                <div className="space-y-3">
                  <Label>I am a:</Label>
                  <div className="flex gap-4">
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="userType"
                        value="user"
                        checked={form.userType === "user"}
                        onChange={(e) => handleInputChange("userType", e.target.value as UserType)}
                        className="text-blue-600"
                      />
                      <span>Parent seeking support</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="userType"
                        value="volunteer"
                        checked={form.userType === "volunteer"}
                        onChange={(e) => handleInputChange("userType", e.target.value as UserType)}
                        className="text-blue-600"
                      />
                      <span>Volunteer helper</span>
                    </label>
                  </div>
                </div>
                {error && <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</div>}
                <Button onClick={handleNext} className="w-full">
                  Next Step
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSignup} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  <Textarea
                    id="bio"
                    placeholder="Tell us a bit about yourself..."
                    value={form.bio}
                    onChange={(e) => handleInputChange("bio", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location (Optional)</Label>
                  <Input
                    id="location"
                    type="text"
                    placeholder="City, State"
                    value={form.location}
                    onChange={(e) => handleInputChange("location", e.target.value)}
                  />
                </div>

                {form.userType === "user" && (
                  <div className="space-y-2">
                    <Label>Children's Ages</Label>
                    <div className="grid grid-cols-3 gap-2">
                      {CHILDREN_AGE_OPTIONS.map((age) => (
                        <label key={age} className="flex items-center space-x-2 cursor-pointer">
                          <Checkbox
                            checked={form.childrenAges?.includes(age) || false}
                            onCheckedChange={() => handleArrayToggle("childrenAges", age)}
                          />
                          <span className="text-sm">{age}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <Label>Interests</Label>
                  <div className="grid grid-cols-1 gap-2">
                    {INTEREST_OPTIONS.map((interest) => (
                      <label key={interest} className="flex items-center space-x-2 cursor-pointer">
                        <Checkbox
                          checked={form.interests?.includes(interest) || false}
                          onCheckedChange={() => handleArrayToggle("interests", interest)}
                        />
                        <span className="text-sm">{interest}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {error && <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">{error}</div>}

                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={() => setStep(1)} className="flex-1">
                    Back
                  </Button>
                  <Button type="submit" className="flex-1" disabled={isLoading}>
                    {isLoading ? "Creating account..." : "Create Account"}
                  </Button>
                </div>
              </form>
            )}

            <div className="mt-6 text-center text-sm">
              <span className="text-gray-600">Already have an account? </span>
              <Link href="/auth/login" className="text-blue-600 hover:text-blue-800 font-medium">
                Sign in
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
